#!/bin/bash
export name
echo "Запускайте скрипт только от рута && Если что-то сломаеться нажми Cntrl + C"
echo "Введите имя пользователя: "
read name
yes | cp -r "$(pwd)/boot" "/"
yes | cp -r "$(pwd)/home/nohashduck/.config" "/home/$name/"
yes | cp -r "$(pwd)/home/nohashduck/.scripts" "/home/$name/"
yes | cp -r "$(pwd)/home/nohashduck/Pictures" "/home/$name/"
yes | cp -r "$(pwd)/home/nohashduck/.bash_profile" "/home/$name/"
yes | cp -r "$(pwd)/home/nohashduck/.vimrc" "/home/$name/"
yes | cp -r "$(pwd)/etc" "/"
yes | chmod -R 777 "/home/$name"
yes | sudo pacman -S neofetch
yes | sudo pacman -S kitty
yes | sudo pacman -S ranger
yes | sudo pacman -S vim
yes | sudo pacman -S git
yes | sudo pacman -S firefox
yes | sudo pacman -S code
yes | sudo pacman -S gnome-boxes
yes | sudo pacman -S sway
yes | sudo pacman -S swaybg
yes | sudo pacman -S waybar
yes | sudo pacman -S wofi
yes | sudo pacman -S mako
yes | sudo pacman -S grim
yes | sudo pacman -S noto-fonts
yes | sudo pacman -S noto-fonts-cjk
yes | sudo pacman -S noto-fonts-emoji
yes | sudo pacman -S otf-font-awesome
yes | sudo pacman -S xorg-xwayland
yes | sudo pacman -S alsa-lib
yes | sudo pacman -S alsa-utils
yes | sudo pacman -S pulseaudio
yes | sudo pacman -S file-roller
yes | sudo pacman -S nautilus
yes | sudo pacman -S htop
yes | sudo pacman -S wl-clipboard
yes | sudo pacman -S zenity
sudo grub-mkconfig -o /boot/grub/grub.cfg
swaymsg reload
